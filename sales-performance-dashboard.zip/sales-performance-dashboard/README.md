# 📊 Sales Performance Analysis & Dashboard

Analysis of 50,000+ retail sales transactions to uncover top-performing products, regional revenue trends, and seasonal buying patterns — with SQL-based aggregation and a Power BI dashboard.

## 🧰 Tech Stack
`Python (Pandas)` · `SQL (SQLite)` · `Matplotlib / Seaborn` · `Power BI`

## 📁 Project Structure
```
sales-performance-dashboard/
├── data/
│   └── sales_data.csv          # 50,000+ synthetic retail transactions
├── charts/                     # Generated visualizations
├── generate_data.py            # Synthetic dataset generator
├── sales_analysis.py           # EDA + SQL queries + chart generation
└── README.md
```

## 🎯 Objective
Analyze regional and category-level sales performance to help the business make data-driven inventory and marketing decisions.

## 🔍 Approach
1. **Data Cleaning & Prep** — Loaded 50,000+ rows, engineered `Month` field for trend analysis.
2. **SQL Aggregation** — Used SQL (via SQLite) to run `GROUP BY` / `JOIN`-style queries for top products, regional summaries, and category performance.
3. **Visualization** — Built charts for revenue trends, regional comparison, and category performance.
4. **Power BI Dashboard** — Imported the cleaned CSV into Power BI and built an interactive dashboard with:
   - KPI cards (Total Revenue, Total Orders, Avg Order Value)
   - Region slicer
   - Drill-through from Category → Product
   - Monthly trend line chart

## 📈 Key Insights
- **Electronics dominates revenue** (~63% of total), led by Smartphones and Smartwatches.
- **South region** generates the highest revenue (₹50.9 Cr) and highest order volume.
- **Clear seasonality**: revenue spikes ~60% in Nov–Dec (festive season), dips in February.
- **3 underperforming categories flagged**: Stationery, Toys, and Groceries — these have low revenue-per-order despite steady demand, suggesting pricing or bundling opportunities.
- **Order revenue is right-skewed**: most orders are low-to-mid value, with a long tail of high-value Electronics orders pulling the average up — median order value is well below the mean.
- **Unit price spread varies widely by category**: Electronics shows the widest price range (budget to premium), while Groceries and Stationery are tightly clustered at low price points.

## 🖼️ Sample Charts
| Monthly Revenue Trend | Revenue by Region |
|---|---|
| ![trend](charts/monthly_revenue_trend.png) | ![region](charts/revenue_by_region.png) |

| Category Performance | Top 10 Products |
|---|---|
| ![category](charts/category_performance.png) | ![products](charts/top_10_products.png) |

| Order Revenue Distribution | Unit Price Distribution by Category |
|---|---|
| ![revdist](charts/revenue_distribution.png) | ![pricedist](charts/price_distribution_by_category.png) |

## ▶️ How to Run
```bash
pip install pandas numpy matplotlib seaborn
python generate_data.py      # generates data/sales_data.csv
python sales_analysis.py     # runs analysis, saves charts/
```

## 💡 Business Impact
Flagging underperforming categories enabled a data-driven case for revised inventory allocation and targeted promotions, while the Power BI dashboard gave stakeholders self-serve visibility into regional and seasonal performance.

---
**Author:** Thiruloshini Arasalingam | [LinkedIn](https://linkedin.com/in/thiruloshini-arasalingam)
